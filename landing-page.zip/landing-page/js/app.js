/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/

const navg =document.getElementById("navbar__list");
const sec =document.querySelectorAll("section");


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions 
 * 
*/

// build the nav


const navgiate =()=>{
    let i =" ";
    sec.forEach(section=>{
        const secId=section.id;
        const secDatNav=section.dataset.nav;
        i=i+`<li><a class="menu__link" href="#${secId}">${secDatNav}</a></li>`;
    });
    navg.innerHTML=i;


};
navgiate();

// Add class 'active' to section when near top of viewport
const funcCond=(section)=>{
    return Math.floor(section.getBoundingClientRect().top);
};

const deleteActive=(section)=>{
    section.classList.remove("your-active-class");
};

const addActive=(cond,section)=>{
    if(cond){
        section.classList.add("your-active-class");
    };
};

const secActive=()=>{
    sec.forEach(section=>{
        const varFuncCond=funcCond(section);
        view=()=> varFuncCond < 100 && varFuncCond >=-100;
        deleteActive(section);
        addActive(view(),section);

    });
};
window.addEventListener("scroll",secActive);


// Scroll to anchor ID using scrollTO event

const scroll=()=>{
    const anchors=document.querySelectorAll(".navbar__menu a");
    anchors.forEach(anchor => {
        anchor.addEventListener("click",()=>{
            for(let j=0;i<sec;j++){
                sec[j].addEventListener("click",sectionScroll(anchor));
            };
        });
    });

};
scroll();

/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


