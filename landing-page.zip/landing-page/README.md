# Landing Page Project

## This is my first project in my scolarship at udacity.
The project is designing landing page using javascript and dom.
I do the project with the skills i learned from udacity.